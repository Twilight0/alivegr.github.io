# -*- coding: utf-8 -*-
"""Subtitle Test - playable items with controlled metadata for subtitle-service testing.

Play any item, then use the subtitle OSD ("Search subtitles") while playing.
Items marked TEST reuse a local file for playback but carry metadata with
known Greek-subtitles coverage (verified against live providers).
"""

import os
import re
import sys
from urllib.parse import parse_qsl, urlencode

import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE = sys.argv[0]

MEDIA_DIR = os.path.expanduser('~/Videos')
PLAYABLE_EXTS = ('.mp4', '.mkv', '.avi')

TEST_ITEMS = [
    {
        'label': '[TEST] The Matrix (1999)',
        'file': 'Videos.mp4',
        'info': {
            'mediatype': 'movie', 'title': 'The Matrix', 'year': 1999,
            'imdbnumber': 'tt0133093', 'plot': 'Subtitle search test item.',
        },
    },
    {
        'label': '[TEST] Breaking Bad S01E01',
        'file': 'Videos.mp4',
        'info': {
            'mediatype': 'episode', 'tvshowtitle': 'Breaking Bad', 'title': 'Pilot',
            'season': 1, 'episode': 1, 'imdbnumber': 'tt0903747',
            'plot': 'Subtitle search test item.',
        },
    },
    {
        'label': '[TEST] Slow Horses S01E01',
        'file': 'Videos.mp4',
        'info': {
            'mediatype': 'episode', 'tvshowtitle': 'Slow Horses', 'title': 'Failure\'s Contagious',
            'season': 1, 'episode': 1, 'imdbnumber': 'tt5875444',
            'plot': 'Subtitle search test item (subs4series report).',
        },
    },
    {
        'label': '[BBB] Big Buck Bunny (2008) - HLS Adaptive (Mux)',
        'url': 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
        'info': {
            'mediatype': 'movie', 'title': 'Big Buck Bunny', 'year': 2008,
            'imdbnumber': 'tt1254207', 'plot': 'Big Buck Bunny multi-bitrate HLS master stream.',
        },
    },
    {
        'label': '[BBB] Big Buck Bunny (2008) - MP4 720p Surround (Archive.org)',
        'url': 'https://archive.org/download/BigBuckBunny_124/Content/big_buck_bunny_720p_surround.mp4',
        'info': {
            'mediatype': 'movie', 'title': 'Big Buck Bunny', 'year': 2008,
            'imdbnumber': 'tt1254207', 'plot': 'Big Buck Bunny 720p MP4 with surround sound.',
        },
    },
    {
        'label': '[BBB] Big Buck Bunny (2008) - AVI 720p (Archive.org)',
        'url': 'https://archive.org/download/BigBuckBunny_124/Content/big_buck_bunny_720p_surround.avi',
        'info': {
            'mediatype': 'movie', 'title': 'Big Buck Bunny', 'year': 2008,
            'imdbnumber': 'tt1254207', 'plot': 'Big Buck Bunny 720p AVI container.',
        },
    },
    {
        'label': '[BBB] Big Buck Bunny (2008) - MP4 360p / 512kb (Archive.org)',
        'url': 'https://archive.org/download/BigBuckBunny_328/BigBuckBunny_512kb.mp4',
        'info': {
            'mediatype': 'movie', 'title': 'Big Buck Bunny', 'year': 2008,
            'imdbnumber': 'tt1254207', 'plot': 'Big Buck Bunny low bitrate MP4.',
        },
    },
]


def _clean_filename(name):
    name = os.path.splitext(name)[0]
    name = re.sub(r'\[\d+\]', '', name).strip()
    return name


def _year_from(name):
    match = re.search(r'\((\d{4})\)', name)
    return int(match.group(1)) if match else 0


def _local_items():
    items = []

    if not os.path.isdir(MEDIA_DIR):
        return items

    for entry in sorted(os.listdir(MEDIA_DIR)):
        if not entry.lower().endswith(PLAYABLE_EXTS):
            continue

        title = _clean_filename(entry)
        year = _year_from(entry)
        info = {'mediatype': 'movie', 'title': title, 'plot': entry}
        if year:
            info['year'] = year

        items.append({'label': title, 'file': entry, 'info': info})

    return items


def list_items():
    for entry in TEST_ITEMS + _local_items():
        if 'url' in entry:
            path = entry['url']
        else:
            path = os.path.join(MEDIA_DIR, entry['file'])

        params = {'action': 'play', 'path': path, 'label': entry['label']}
        params.update({k: v for k, v in entry['info'].items() if k != 'plot'})
        params['plot'] = entry['info'].get('plot', '')
        url = '{0}?{1}'.format(BASE, urlencode(params))

        item = xbmcgui.ListItem(label=entry['label'])
        item.setInfo('video', entry['info'])
        item.setProperty('IsPlayable', 'true')

        # Add context menu options to trigger downloader with folder prompt
        dl_params = {'action': 'download', 'path': path, 'label': entry['label'], 'prefer_ffmpeg': 'true'}
        dl_url = 'RunPlugin({0}?{1})'.format(BASE, urlencode(dl_params))

        dl_py_params = {'action': 'download', 'path': path, 'label': entry['label'], 'prefer_ffmpeg': 'false'}
        dl_py_url = 'RunPlugin({0}?{1})'.format(BASE, urlencode(dl_py_params))

        context_menu = [
            ('Download (FFmpeg if available)...', dl_url),
            ('Download (Pure Python only)...', dl_py_url)
        ]
        item.addContextMenuItems(context_menu)

        xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)


def play(params):
    item = xbmcgui.ListItem(label=params.get('label', ''), path=params['path'])
    info = {'mediatype': 'movie', 'title': params.get('title', params.get('label', ''))}

    for key in ('year', 'season', 'episode'):
        if params.get(key):
            try:
                info[key] = int(params[key])
            except (TypeError, ValueError):
                pass

    for key in ('tvshowtitle', 'imdbnumber', 'plot', 'title'):
        if params.get(key):
            info[key] = params[key]

    if 'tvshowtitle' in info:
        info['mediatype'] = 'episode'

    item.setInfo('video', info)
    xbmcplugin.setResolvedUrl(HANDLE, True, item)


def download(params):
    """Prompts user to select download directory, then delegates to Tulip getter."""
    target_path = params.get('path', '')
    if not target_path:
        return

    prefer_ffmpeg = params.get('prefer_ffmpeg', 'true').lower() == 'true'

    # Prompt user for destination directory using Kodi's native folder browser
    selected_dir = xbmcgui.Dialog().browse(0, 'Select Download Folder', 'video')
    if not selected_dir:
        return  # User cancelled

    label = params.get('label', 'Video')
    clean_title = re.sub(r'\[.*?\]', '', label).strip()
    engine_name = 'FFmpeg' if prefer_ffmpeg else 'Pure Python'

    try:
        from tulip import getter

        if target_path.endswith('.m3u8') or '.m3u8' in target_path:
            # HLS stream: Tulip M3U8 handles quality picking and multi-tier downloading
            xbmc.log('[subtest] Starting HLS download ({0}) for {1} to {2}'.format(engine_name, target_path, selected_dir), xbmc.LOGINFO)
            m = getter.M3U8(target_path, heading='Select Quality - ' + clean_title)
            dest = m.downloader(
                selected_dir,
                heading='Downloading ({0}) - {1}'.format(engine_name, clean_title),
                prefer_ffmpeg=prefer_ffmpeg,
                concurrency=5
            )
        else:
            # Direct media file (.mp4, .avi, etc.)
            xbmc.log('[subtest] Starting direct download for {0} to {1}'.format(target_path, selected_dir), xbmc.LOGINFO)
            dest = getter.download_media(target_path, selected_dir, heading='Downloading ' + clean_title)

        if dest:
            xbmcgui.Dialog().notification('Download Complete ({0})'.format(engine_name), os.path.basename(dest), xbmcgui.NOTIFICATION_INFO, 4000)

    except Exception as err:
        xbmc.log('[subtest] Download error: {0}'.format(err), xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Download Failed', str(err), xbmcgui.NOTIFICATION_ERROR, 4000)


if __name__ == '__main__':
    args = dict(parse_qsl(sys.argv[2][1:]))
    action = args.get('action')

    if action == 'play':
        play(args)
    elif action == 'download':
        download(args)
    else:
        list_items()
